# Days to change the status from red (danger) to yellow (warning)
DAYS_FROM_DANGER_TO_WARNING = 5
# Days to change the status from blue (info) to green (success)
DAYS_FROM_INFO_TO_SUCCESS = 1
# Time to wait after each host check in seconds (0..) 
WAIT_FOR_NEXT = 1
# Max log lines for each host
MAX_LOG = 10
